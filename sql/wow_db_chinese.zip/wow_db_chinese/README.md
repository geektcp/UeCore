wow_db_chinese
==============

CMangos数据库汉化

所有数据来自互联网
我只当搬运工

fork 自 keyshuwen <285196897@qq.com>

做了一些 cmangos clasic-db 的适应和些许翻译数据优化。
