use mangos;
INSERT INTO `gossip_menu_option` VALUES ('0','16','0','GOSSIP_OPTION_BOT','99', '1','0', '0', '0', '0', '0', NULL, '0');
