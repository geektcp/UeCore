use realmd;

SET
@username = "test1",
@password = "123",
@email = "geektcp@163.com",
@expansion = 0,  -- 0��ʾ�����ʱ�� 1��ʾ70�����һ������
@gmlevel = 0,   -- 0 = player, 1=GM, 2=Moderator, 3=Admin, 4=Console
@realmid = 1;

INSERT INTO account 
(username, sha_pass_hash, gmlevel, email, expansion, active_realm_id)
VALUES (
UPPER(@username), 
(SHA1(CONCAT(UPPER(@username), 
':', UPPER (@password))) ), 
@gmlevel, 
@email, 
@expansion,
@realmid
);

INSERT INTO `realmd`.`realmcharacters` (`realmid`, `acctid`) VALUES ('1', '5');

